#g++ -std=c++11 main.cpp -o main -lpthread -g
g++ -o main_test intense_tests/main.cpp threads.o -m32 